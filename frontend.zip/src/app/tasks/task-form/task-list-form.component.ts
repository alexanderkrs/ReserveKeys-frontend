import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task-list-form',
  templateUrl: './task-list-form.component.html',
  styleUrls: ['./task-list-form.component.css']
})
export class TaskListFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
